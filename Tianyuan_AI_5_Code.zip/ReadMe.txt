AI_CSP is the archive file for the project. To run the project import the AI_CSP.zip
into Eclipse and run the MapColorDriver.java or CircuitBoardDriver.java